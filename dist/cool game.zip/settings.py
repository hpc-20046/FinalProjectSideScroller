import pygame

WIDTH = 1920
HEIGHT = 1080

cell_width = 40
cell_height = 40

TARGET_FPS = 60